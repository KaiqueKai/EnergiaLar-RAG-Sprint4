import json

from src.config import BASELINE_RESULTS_FILE, COMPARISON_RESULTS_FILE


def media(dados: list[dict], campo: str):
    valores = [
        item[campo]
        for item in dados
        if item.get("status", "OK") == "OK" and item.get(campo) is not None
    ]
    if not valores:
        return None
    return sum(valores) / len(valores)


def _media_formatada(valor, sufixo: str = "") -> str:
    if valor is None:
        return "não disponível"
    return f"{valor:.2f}{sufixo}"


def main() -> None:
    if not BASELINE_RESULTS_FILE.exists():
        print(f"Arquivo não encontrado: {BASELINE_RESULTS_FILE}")
        print("Execute primeiro: python -m evals.run_baseline")
        return

    if not COMPARISON_RESULTS_FILE.exists():
        print(f"Arquivo não encontrado: {COMPARISON_RESULTS_FILE}")
        print("Execute primeiro: python -m evals.model_comparison")
        return

    baseline = json.loads(BASELINE_RESULTS_FILE.read_text(encoding="utf-8"))
    sprint3 = json.loads(COMPARISON_RESULTS_FILE.read_text(encoding="utf-8"))

    baseline_tokens = media(baseline, "tokens_resposta")
    baseline_latencia = media(baseline, "latencia_segundos")

    print("=" * 80)
    print("COMPARAÇÃO SPRINT 2 x SPRINT 3")
    print("=" * 80)

    print("\nSPRINT 2 - BASELINE")
    print(f"Média de tokens: {_media_formatada(baseline_tokens)}")
    print(f"Latência média: {_media_formatada(baseline_latencia, ' segundos')}")

    modelos = sorted({item["modelo"] for item in sprint3})
    for modelo in modelos:
        dados = [item for item in sprint3 if item["modelo"] == modelo]
        sprint3_tokens = media(dados, "tokens_resposta")
        sprint3_latencia = media(dados, "latencia_segundos")
        validos = sum(1 for item in dados if item.get("status") == "OK")

        print(f"\nSPRINT 3 - {modelo}")
        print(f"Casos concluídos: {validos}/{len(dados)}")
        print(f"Média de tokens: {_media_formatada(sprint3_tokens)}")
        print(f"Latência média: {_media_formatada(sprint3_latencia, ' segundos')}")

        if baseline_tokens is not None and sprint3_tokens is not None:
            print(f"Diferença média de tokens: {sprint3_tokens - baseline_tokens:+.2f}")

        if baseline_latencia is not None and sprint3_latencia is not None:
            print(
                "Diferença de latência: "
                f"{sprint3_latencia - baseline_latencia:+.2f} segundos"
            )


if __name__ == "__main__":
    main()
