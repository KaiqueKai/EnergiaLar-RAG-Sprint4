import json
import time

import tiktoken

from src.chatbot import criar_chatbot, responder
from src.config import CASES_FILE, COMPARISON_MODELS, COMPARISON_RESULTS_FILE
from src.schemas.consulta_recarga import ConsultaRecarga


ENCODING = tiktoken.get_encoding("cl100k_base")
MODELOS = COMPARISON_MODELS


def contar_tokens(texto: str) -> int:
    """Conta os tokens da resposta com uma codificação fixa para comparação."""
    return len(ENCODING.encode(texto))


def validar_estrutura(resultado: object) -> bool:
    """Verifica se o resultado respeita o contrato Pydantic."""
    if isinstance(resultado, ConsultaRecarga):
        return True

    if isinstance(resultado, dict):
        campos = {
            "estado_carregador",
            "potencia_kw",
            "faturamento_reais",
            "resposta",
        }
        return campos.issubset(resultado.keys())

    return False


def _resultado_erro(modelo: str, caso: dict, erro: Exception, latencia: float) -> dict:
    return {
        "modelo": modelo,
        "id": caso["id"],
        "pergunta": caso["pergunta"],
        "resposta": None,
        "tokens_resposta": None,
        "latencia_segundos": round(latencia, 2),
        "estrutura_valida": False,
        "status": "ERRO",
        "erro": str(erro),
    }


def avaliar_modelo(modelo: str, casos: list[dict]) -> list[dict]:
    """Executa todos os casos sem interromper o restante da avaliação."""
    print("\n" + "=" * 80)
    print(f"MODELO: {modelo}")
    print("=" * 80)

    try:
        chatbot = criar_chatbot(modelo)
    except Exception as erro:
        print(f"Falha ao inicializar o modelo: {erro}")
        return [_resultado_erro(modelo, caso, erro, 0.0) for caso in casos]

    resultados: list[dict] = []

    for caso in casos:
        session_id = f"comparacao_{modelo}_{caso['id']}"
        inicio = time.perf_counter()

        try:
            resultado = responder(
                chatbot,
                caso["pergunta"],
                session_id=session_id,
            )
            latencia = time.perf_counter() - inicio
            texto = resultado.resposta
            estrutura_valida = validar_estrutura(resultado)

            item = {
                "modelo": modelo,
                "id": caso["id"],
                "pergunta": caso["pergunta"],
                "resposta": texto,
                "tokens_resposta": contar_tokens(texto),
                "latencia_segundos": round(latencia, 2),
                "estrutura_valida": estrutura_valida,
                "status": "OK" if estrutura_valida else "ERRO",
            }

            print(f"\nCASO {caso['id']}")
            print(f"Tokens: {item['tokens_resposta']}")
            print(f"Latência: {latencia:.2f} segundos")
            print(
                "Estrutura Pydantic: "
                f"{'OK' if estrutura_valida else 'ERRO'}"
            )
        except Exception as erro:
            latencia = time.perf_counter() - inicio
            item = _resultado_erro(modelo, caso, erro, latencia)
            print(f"\nCASO {caso['id']}")
            print(f"ERRO: {erro}")

        resultados.append(item)

    return resultados


def salvar_resultados(resultados: list[dict]) -> None:
    COMPARISON_RESULTS_FILE.write_text(
        json.dumps(resultados, ensure_ascii=False, indent=4),
        encoding="utf-8",
    )
    print(f"\nResultados salvos em: {COMPARISON_RESULTS_FILE}")


def mostrar_resumo(resultados: list[dict]) -> None:
    print("\n" + "=" * 80)
    print("RESUMO DA COMPARAÇÃO")
    print("=" * 80)

    for modelo in MODELOS:
        dados = [item for item in resultados if item["modelo"] == modelo]
        validos = [item for item in dados if item.get("status") == "OK"]

        print(f"\nModelo: {modelo}")
        print(f"Casos concluídos: {len(validos)}/{len(dados)}")

        if not validos:
            print("Média de tokens: não disponível")
            print("Latência média: não disponível")
            print("Estruturas válidas: 0/0")
            continue

        media_tokens = sum(item["tokens_resposta"] for item in validos) / len(validos)
        media_latencia = sum(item["latencia_segundos"] for item in validos) / len(validos)
        estruturas_validas = sum(1 for item in validos if item["estrutura_valida"])

        print(f"Média de tokens: {media_tokens:.2f}")
        print(f"Latência média: {media_latencia:.2f} segundos")
        print(f"Estruturas válidas: {estruturas_validas}/{len(validos)}")


def main() -> None:
    casos = json.loads(CASES_FILE.read_text(encoding="utf-8"))
    todos_resultados: list[dict] = []

    for modelo in MODELOS:
        todos_resultados.extend(avaliar_modelo(modelo, casos))

    salvar_resultados(todos_resultados)
    mostrar_resumo(todos_resultados)


if __name__ == "__main__":
    main()
