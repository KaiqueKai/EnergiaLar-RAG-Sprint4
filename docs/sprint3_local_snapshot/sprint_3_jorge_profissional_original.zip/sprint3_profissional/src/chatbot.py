import json
import re
from typing import Any

from langchain_core.chat_history import InMemoryChatMessageHistory
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_ollama import ChatOllama

from src.config import SYSTEM_PROMPT_FILE, TEMPERATURE, read_prompt
from src.schemas.consulta_recarga import ConsultaRecarga


SESSIONS: dict[str, InMemoryChatMessageHistory] = {}
SYSTEM_PROMPT = read_prompt(SYSTEM_PROMPT_FILE)


def _get_session_history(session_id: str) -> InMemoryChatMessageHistory:
    """Cria ou recupera a memória de uma sessão."""
    if session_id not in SESSIONS:
        SESSIONS[session_id] = InMemoryChatMessageHistory()
    return SESSIONS[session_id]


def criar_chatbot(modelo: str):
    """Cria a cadeia LCEL com memória por sessão."""
    llm = ChatOllama(
        model=modelo,
        temperature=TEMPERATURE,
    )

    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", SYSTEM_PROMPT),
            MessagesPlaceholder(variable_name="history"),
            ("human", "{pergunta}"),
        ]
    )

    chain = prompt | llm

    return RunnableWithMessageHistory(
        chain,
        _get_session_history,
        input_messages_key="pergunta",
        history_messages_key="history",
    )


def _extrair_json(texto: str) -> str:
    """Extrai o primeiro objeto JSON encontrado no texto recebido."""
    texto = texto.strip()
    texto = re.sub(r"^```(?:json)?\s*", "", texto, flags=re.IGNORECASE)
    texto = re.sub(r"\s*```$", "", texto)
    texto = texto.strip()

    inicio = texto.find("{")
    fim = texto.rfind("}")

    if inicio == -1 or fim == -1 or fim < inicio:
        raise ValueError("O modelo não retornou um objeto JSON válido.")

    return texto[inicio : fim + 1]


def _normalizar_content(content: Any) -> str:
    """Transforma diferentes formatos de content em texto."""
    if isinstance(content, str):
        return content

    if isinstance(content, list):
        partes: list[str] = []
        for item in content:
            if isinstance(item, dict) and "text" in item:
                partes.append(str(item["text"]))
            else:
                partes.append(str(item))
        return "".join(partes)

    return str(content)


def _normalizar_resultado(resultado: Any) -> ConsultaRecarga:
    """Converte a saída da cadeia em um objeto Pydantic validado."""
    if isinstance(resultado, ConsultaRecarga):
        return resultado

    if isinstance(resultado, dict):
        return ConsultaRecarga.model_validate(resultado)

    content = getattr(resultado, "content", None)
    if content is None:
        raise TypeError(
            f"Tipo de resposta inesperado: {type(resultado).__name__}"
        )

    texto = _normalizar_content(content)
    dados = json.loads(_extrair_json(texto))
    return ConsultaRecarga.model_validate(dados)


def responder(
    chatbot,
    pergunta: str,
    session_id: str = "default",
) -> ConsultaRecarga:
    """Envia uma pergunta e devolve uma resposta Pydantic validada."""
    if not pergunta or not pergunta.strip():
        raise ValueError("A pergunta não pode ser vazia.")

    resultado = chatbot.invoke(
        {"pergunta": pergunta.strip()},
        config={"configurable": {"session_id": session_id}},
    )

    return _normalizar_resultado(resultado)


def limpar_sessoes() -> None:
    """Limpa a memória de todas as sessões em memória."""
    SESSIONS.clear()
