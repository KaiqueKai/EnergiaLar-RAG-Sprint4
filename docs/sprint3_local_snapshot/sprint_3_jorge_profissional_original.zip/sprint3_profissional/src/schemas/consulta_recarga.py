from pydantic import BaseModel, Field


class ConsultaRecarga(BaseModel):
    """Contrato estruturado para as respostas do assistente."""

    estado_carregador: str | None = Field(
        default=None,
        description="Estado do carregador, quando houver essa informação.",
    )
    potencia_kw: float | None = Field(
        default=None,
        description="Potência do carregador em kW, quando houver informação suficiente.",
    )
    faturamento_reais: float | None = Field(
        default=None,
        description="Faturamento em reais, quando houver informação suficiente para calculá-lo.",
    )
    resposta: str = Field(
        min_length=1,
        description="Resposta objetiva e útil para a pergunta do usuário.",
    )
