"""Testes automatizados do projeto."""
