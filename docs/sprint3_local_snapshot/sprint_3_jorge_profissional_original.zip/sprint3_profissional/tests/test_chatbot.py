import pytest

from src.chatbot import _extrair_json, _normalizar_resultado
from src.schemas.consulta_recarga import ConsultaRecarga


def test_extrair_json_remove_markdown():
    texto = '```json\n{"resposta":"teste"}\n```'
    assert _extrair_json(texto) == '{"resposta":"teste"}'


def test_extrair_json_encontra_objeto_no_texto():
    texto = 'resultado: {"resposta":"teste"}'
    assert _extrair_json(texto) == '{"resposta":"teste"}'


def test_extrair_json_rejeita_texto_sem_objeto():
    with pytest.raises(ValueError):
        _extrair_json("sem json")


def test_normalizar_resultado_pydantic():
    resultado = _normalizar_resultado(
        '{"estado_carregador":null,"potencia_kw":null,'
        '"faturamento_reais":null,"resposta":"teste"}'
    )

    assert isinstance(resultado, ConsultaRecarga)
    assert resultado.resposta == "teste"
