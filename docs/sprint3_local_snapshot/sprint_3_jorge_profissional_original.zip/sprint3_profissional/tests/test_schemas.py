import pytest
from pydantic import ValidationError

from src.schemas.consulta_recarga import ConsultaRecarga


def test_consulta_recarga_valida():
    resultado = ConsultaRecarga(
        estado_carregador="Disponível",
        potencia_kw=22.0,
        faturamento_reais=None,
        resposta="O carregador está disponível para uso.",
    )

    assert resultado.estado_carregador == "Disponível"
    assert resultado.potencia_kw == 22.0
    assert resultado.resposta


def test_consulta_recarga_aceita_nulos():
    resultado = ConsultaRecarga(
        estado_carregador=None,
        potencia_kw=None,
        faturamento_reais=None,
        resposta="Não há dados suficientes para informar esses valores.",
    )

    assert resultado.potencia_kw is None
    assert resultado.faturamento_reais is None


def test_consulta_recarga_rejeita_resposta_vazia():
    with pytest.raises(ValidationError):
        ConsultaRecarga(resposta="")
